#ifndef __BEEP_H
#define __BEEP_H	 
#include "common.h"
  
void BEEP_Init(void);
void BEEP_ON(void);
void BEEP_OFF(void);
void BEEP_Toggle(void);


#endif
