#include "stm32f10x.h"


#define LED0 PFOUT(7)	// PF7		  DS4
#define LED1 PFOUT(8)	// PF8		  DS3
#define LED2 PFOUT(9)	// PF9		  DS2
#define LED3 PFOUT(10)	// PF10		  DS1

void LED_Init(void);

		 				    
