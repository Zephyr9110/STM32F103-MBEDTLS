#include "stm32f10x.h"


void SysTick_Init(uint32_t a);

void LED_Init(void);

		 				    

