#include "BKPTest.h"
#include "main.h"


#include "stm32f10x_rtc.h"

void BKPTest(void)
{
	
	;
}