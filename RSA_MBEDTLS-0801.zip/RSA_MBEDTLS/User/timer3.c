#include "stm32f10x.h"
#include "stm32f10x_tim.h"
#include "timer3.h"

//>>72M TIM3 ʱ��Ƶ�� һ��pulse��ʱ��Ϊ 1000ns / 72 = 13.9ns,
//>>����800kbps�Ĵ������ʣ�ÿ��bit����ʱ�� 1000000us / 800000 = 1.25us
//>>����һ��pwm������Ϊ 1250ns / 13.9 = 90
//>>����2812C��ʱ��Ҫ��T0_H ����ȡ  300ns / 13.9ns = 22 
//>>����2812C��ʱ��Ҫ��T1_H ����ȡ  800ns / 13.9ns = 57
//>>LED����ʾ��Ҫ�ȹ�280us�ĵȴ����ڣ�280us / 1.25us = 230 
#define LED_T0_H_PULSE  22
#define LED_T1_H_PULSE  57
#define LED_T0_1_PERIOD 90
//>>LED ������

//>> TIM3 CH3 OFFSET ADDR
#define TIM3_CH3_CCR3_ADDR   (TIM3_BASE + 0x3C)
//>>��ԭɫÿ����ɫ���ɫ��255����1���ֽڣ�����ɫ��3���ֽڣ�����24bit,��
//>>�ټ���230��bit��reset���ڣ�ȫ����������Ҫ���¸�bit number
#define BIT_TRANSFER_NUM      (24 * LED_NUM + 230)
uint16_t DMA_WS2812_Buf[BIT_TRANSFER_NUM] = {0};
uint8_t Time3SetFlag = 0;

static uint8_t  TimerFlg = FALSE ;

void SetTimerFlg(void)
{
	TimerFlg=TRUE;
}

void ResetTimerFlg(void)
{
	TimerFlg=FALSE;
}
uint8_t GetTimerFlag(void)
{
      if(TimerFlg == TRUE)
              return 1;
      else
              return 0;	
}
/**-------------------------------------------------------
  * @������ NVIC_TIM5Configuration
  * @����   ����TIM5�ж�������������
  * @����   ��
  * @����ֵ ��
***------------------------------------------------------*/
static void NVIC_TIM2Enbale(void)
{ 
    NVIC_InitTypeDef NVIC_InitStructure;

    /* Set the Vector Table base address at 0x08000000 */
    //NVIC_SetVectorTable(NVIC_VectTab_FLASH, 0x0000);

    /* Enable the TIM5 gloabal Interrupt */
    NVIC_InitStructure.NVIC_IRQChannel =  TIM2_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure);
}
//static void NVIC_TIM3Enbale(void)
//{ 
//    NVIC_InitTypeDef NVIC_InitStructure;
//
//    /* Set the Vector Table base address at 0x08000000 */
//    //NVIC_SetVectorTable(NVIC_VectTab_FLASH, 0x0000);
//
//    /* Enable the TIM5 gloabal Interrupt */
//    NVIC_InitStructure.NVIC_IRQChannel =  TIM3_IRQn;
//    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 3;
//    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;
//    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
//    NVIC_Init(&NVIC_InitStructure);
//}
void NVIC_TIM3Disbale(void)
{ 
    NVIC_InitTypeDef NVIC_InitStructure;
    /* Set the Vector Table base address at 0x08000000 */
    //NVIC_SetVectorTable(NVIC_VectTab_FLASH, 0x0000);

    /* Enable the TIM2 gloabal Interrupt */
    NVIC_InitStructure.NVIC_IRQChannel =  TIM3_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 3;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;
    NVIC_InitStructure.NVIC_IRQChannelCmd = DISABLE;
    NVIC_Init(&NVIC_InitStructure);
}
void TIM4_Init(void)
{
	//NVIC_InitTypeDef NVIC_InitStructure;
	TIM_TimeBaseInitTypeDef  TIM_TimeBaseStructure;
    NVIC_InitTypeDef NVIC_InitStructure;

    /* Set the Vector Table base address at 0x08000000 */
    //NVIC_SetVectorTable(NVIC_VectTab_FLASH, 0x0000);


    /* TIM5 clock enable */
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM4, ENABLE);

    /* ---------------------------------------------------------------
    TIM4 Configuration: Output Compare Timing Mode:
    TIM2CLK = 36 MHz, Prescaler = 7200, TIM2 counter clock = 7.2 MHz
    --------------------------------------------------------------- */

    /* Time base configuration */
    //��������Զ�װ�صļ���ֵ�����ڼ����Ǵ�0��ʼ�ģ�����10000�κ�Ϊ9999
    TIM_TimeBaseStructure.TIM_Period = 71;//(10000 - 1);
    // �������Ԥ��Ƶϵ����������Ϊ0ʱ��ʾ����Ƶ����Ҫ��1
    TIM_TimeBaseStructure.TIM_Prescaler = 2;//(7200 - 1);
    // �߼�Ӧ�ñ��β��漰�������ڶ�ʱ��ʱ��(CK_INT)Ƶ���������˲���(ETR,TIx)
    // ʹ�õĲ���Ƶ��֮��ķ�Ƶ����
    TIM_TimeBaseStructure.TIM_ClockDivision = 0;
    //���ϼ���
    TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;
    //��ʼ����ʱ��5
    TIM_TimeBaseInit(TIM4, &TIM_TimeBaseStructure);

    /* Clear TIM2 update pending flag[���TIM2����жϱ�־] */
    TIM_ClearITPendingBit(TIM4, TIM_IT_Update);

    /* TIM IT enable */ //������ж�
    TIM_ITConfig(TIM4, TIM_IT_Update, ENABLE);

    //TIM_Cmd(TIM4, ENABLE);  //������ʹ�ܣ���ʼ����
	    /* Enable the TIM5 gloabal Interrupt */
    NVIC_InitStructure.NVIC_IRQChannel =  TIM4_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure);	
}

void TIM2_Init(void)
{
	//NVIC_InitTypeDef NVIC_InitStructure;
	TIM_TimeBaseInitTypeDef  TIM_TimeBaseStructure;

    /* TIM5 clock enable */
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2, ENABLE);

    /* ---------------------------------------------------------------
    TIM4 Configuration: Output Compare Timing Mode:
    TIM2CLK = 36 MHz, Prescaler = 7200, TIM2 counter clock = 7.2 MHz
    --------------------------------------------------------------- */

    /* Time base configuration */
    //��������Զ�װ�صļ���ֵ�����ڼ����Ǵ�0��ʼ�ģ�����10000�κ�Ϊ9999
    TIM_TimeBaseStructure.TIM_Period = 72;//(10000 - 1);
    // �������Ԥ��Ƶϵ����������Ϊ0ʱ��ʾ����Ƶ����Ҫ��1
    TIM_TimeBaseStructure.TIM_Prescaler = 0;//(7200 - 1);
    // �߼�Ӧ�ñ��β��漰�������ڶ�ʱ��ʱ��(CK_INT)Ƶ���������˲���(ETR,TIx)
    // ʹ�õĲ���Ƶ��֮��ķ�Ƶ����
    TIM_TimeBaseStructure.TIM_ClockDivision = 0;
    //���ϼ���
    TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;
    //��ʼ����ʱ��5
    TIM_TimeBaseInit(TIM2, &TIM_TimeBaseStructure);

    /* Clear TIM2 update pending flag[���TIM2����жϱ�־] */
    TIM_ClearITPendingBit(TIM2, TIM_IT_Update);

    /* TIM IT enable */ //������ж�
    TIM_ITConfig(TIM2, TIM_IT_Update, ENABLE);
   
	SetTimerFlg();
    /* �жϲ������� */
    //NVIC_TIM2Enbale();
		/* TIM5 enable counter */

    TIM_Cmd(TIM2, ENABLE);  //������ʹ�ܣ���ʼ����
	NVIC_TIM2Enbale();	
}
void PWM_DMA_Init(void)
{
    GPIO_InitTypeDef GPIO_InitStructure;
    TIM_OCInitTypeDef TIM_OCInitStructure;
    TIM_TimeBaseInitTypeDef  TIM_TimeBaseStructure;
    DMA_InitTypeDef  DMA_InitStruct;

    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB | RCC_APB2Periph_AFIO, ENABLE);
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM3, ENABLE);
    RCC_AHBPeriphClockCmd(RCC_AHBPeriph_DMA1,ENABLE);
    
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz; 
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
    GPIO_Init(GPIOB,&GPIO_InitStructure);
    DMA_DeInit(DMA1_Channel2);
    DMA_InitStruct.DMA_PeripheralBaseAddr = TIM3_CH3_CCR3_ADDR; 
    DMA_InitStruct.DMA_MemoryBaseAddr = (uint32_t)DMA_WS2812_Buf;   
    DMA_InitStruct.DMA_DIR = DMA_DIR_PeripheralDST;               
    DMA_InitStruct.DMA_BufferSize = BIT_TRANSFER_NUM;        
    DMA_InitStruct.DMA_PeripheralInc = DMA_PeripheralInc_Disable;     
    DMA_InitStruct.DMA_MemoryInc = DMA_MemoryInc_Enable;         
    DMA_InitStruct.DMA_PeripheralDataSize = DMA_PeripheralDataSize_HalfWord; 
    DMA_InitStruct.DMA_MemoryDataSize = DMA_MemoryDataSize_HalfWord;    
    DMA_InitStruct.DMA_Mode = DMA_Mode_Circular;             
    DMA_InitStruct.DMA_Priority = DMA_Priority_High;         
    DMA_InitStruct.DMA_M2M = DMA_M2M_Disable;
    DMA_Init(DMA1_Channel2,&DMA_InitStruct);
    
    /* ---------------------------------------------------------------
    TIM3 Configuration: Output Compare Timing Mode:
    TIM3CLK = 36 MHz, Prescaler = 7200, TIM2 counter clock = 7.2 MHz
    --------------------------------------------------------------- */
    /* Time base configuration */
    TIM_DeInit(TIM3);
    TIM_TimeBaseStructure.TIM_Period = LED_T0_1_PERIOD;
    TIM_TimeBaseStructure.TIM_Prescaler = 0;
    TIM_TimeBaseStructure.TIM_ClockDivision = TIM_CKD_DIV1;
    TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;
    TIM_TimeBaseStructure.TIM_RepetitionCounter = 0;
    TIM_TimeBaseInit(TIM3, &TIM_TimeBaseStructure);
    /* Channel 1, 2,3 and 4 Configuration in PWM mode */
    TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM1;
    TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable;
    TIM_OCInitStructure.TIM_OutputNState = TIM_OutputState_Disable;
    TIM_OCInitStructure.TIM_Pulse = 0;
    TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_High;
    TIM_OCInitStructure.TIM_OCNPolarity = TIM_OCPolarity_High;//���� TIM_OCNPolarity_High ͬ��; 
    TIM_OCInitStructure.TIM_OCIdleState = TIM_OCIdleState_Set;
    TIM_OCInitStructure.TIM_OCNIdleState =TIM_OCIdleState_Reset;//TIM_OCIdleState_Set;
    TIM_OC3Init(TIM3, &TIM_OCInitStructure);            
//    TIM_ClearITPendingBit(TIM3, TIM_IT_Update);
//    //TIM_ClearITPendingBit(TIM3, TIM_IT_CC1);
//    TIM_ITConfig(TIM3, TIM_IT_Update, ENABLE);
//    //TIM_ITConfig(TIM3, TIM_IT_CC1, ENABLE);
//    NVIC_TIM3Enbale();
   // TIM_ARRPreloadConfig(TIM3,ENABLE);
    TIM_OC3PreloadConfig(TIM3,TIM_OCPreload_Enable);
  //  TIM_DMAConfig(TIM3,TIM_DMABase_CCR3,TIM_DMABurstLength_1Transfer);
    TIM_DMACmd(TIM3,TIM_DMA_CC3,ENABLE);
    DMA_Cmd(DMA1_Channel2,ENABLE);
    TIM_Cmd(TIM3,ENABLE); 	
}

void TIM3_Init(void)
{


    TIM_TimeBaseInitTypeDef  TIM_TimeBaseStructure;
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM3, ENABLE);
    NVIC_InitTypeDef NVIC_InitStructure;
    /* Set the Vector Table base address at 0x08000000 */
    //NVIC_SetVectorTable(NVIC_VectTab_FLASH, 0x0000);
    /* ---------------------------------------------------------------
    TIM3 Configuration: Output Compare Timing Mode:
    TIM3CLK = 36 MHz, Prescaler = 7200, TIM2 counter clock = 7.2 MHz
    --------------------------------------------------------------- */
    /* Time base configuration */
    TIM_DeInit(TIM3);
    TIM_TimeBaseStructure.TIM_Period = 2000 - 1;
    TIM_TimeBaseStructure.TIM_Prescaler = 36000 - 1;
    TIM_TimeBaseStructure.TIM_ClockDivision = TIM_CKD_DIV1;
    TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;
    TIM_TimeBaseStructure.TIM_RepetitionCounter = 0;
    TIM_TimeBaseInit(TIM3, &TIM_TimeBaseStructure);       
   	
	
	TIM_ClearITPendingBit(TIM3, TIM_IT_Update);
	TIM_ITConfig(TIM3, TIM_IT_Update, ENABLE);

	    /* Enable the TIM2 gloabal Interrupt */
    NVIC_InitStructure.NVIC_IRQChannel =  TIM3_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 3;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure);
	Time3SetFlag = 1;
	TIM_Cmd(TIM3,ENABLE); 
}


void Tim3Int_Enable(void)
{    
	TIM_Cmd(TIM3,DISABLE); 	    
	TIM_ClearITPendingBit(TIM3, TIM_IT_Update);
	TIM_ITConfig(TIM3, TIM_IT_Update, ENABLE);
	NVIC_TIM3Enbale();
	TIM_Cmd(TIM3,ENABLE); 
	
}
/***********************************************************
* Function Name : LedSetColor
* Description : set every led color .
* Input :  LedIndex, color, britness
* Output : None
* Return : None
*************************************************************/
void LedSetColor(uint8_t LedIndex,uint8_t color,uint8_t britness)
{
    uint8_t r = 0;
    uint8_t g = 0;
    uint8_t b = 0;
    r = r;
    g = g;
    b = b;
    switch(color)
    {
        case 1:
            r = britness;
            break;
        case 2:
            g = britness;
            break;
        case 3:
            b = britness;
            break;
        case 4:
            r = britness;
            g = britness;
            break;
        case 5:
            r = britness;
            b = britness;
        break;
        case 6:
            g = britness;
            b = britness;
            break;
        case 7:
            r = britness;
            g = britness;
            b = britness;
            break;
        case 0 :
          
        default:
             break;   
    }
    int idx = 0;
    for(uint8_t i = 0;i < 8;i ++)
    {
        if((r << i) & 0x80) {
            DMA_WS2812_Buf[LedIndex * 24 + i] = LED_T1_H_PULSE;
        } else {
            DMA_WS2812_Buf[LedIndex * 24 + i] = LED_T0_H_PULSE;
        }
        
    }
     idx += 8;
    for(uint8_t i = 0;i < 8;i ++)
    {
        if((g << i) & 0x80) {
            DMA_WS2812_Buf[LedIndex * 24 + i + idx] = LED_T1_H_PULSE;
        } else {
            DMA_WS2812_Buf[LedIndex * 24 + i + idx] = LED_T0_H_PULSE;
        }    
    }
    idx += 8;
    for(uint8_t i = 0;i < 8;i ++)
    {
        if((b << i) & 0x80) {
            DMA_WS2812_Buf[LedIndex * 24 + i + idx] = LED_T1_H_PULSE;
        } else {
            DMA_WS2812_Buf[LedIndex * 24 + i + idx] = LED_T0_H_PULSE;
        }      
    }
    
}
/***********************************************************
* Function Name : LedSetColor
* Description : set every led color .
* Input :  LedIndex, color, britness
* Output : None
* Return : None
*************************************************************/
void LedColorReset()
{
    for(uint8_t i = 0;i < LED_NUM;i ++)
    {
        LedSetColor(i,0,0);
    }
}
void SetTim3Period(uint8_t period)
{
    TIM_TimeBaseInitTypeDef  TIM_TimeBaseStructure;
    TIM_TimeBaseStructure.TIM_Period = period;
    TIM_TimeBaseInit(TIM3, &TIM_TimeBaseStructure);
    TIM_Cmd(TIM3, ENABLE); 	 
}

/**-------------------------------------------------------
  * @������ NVIC_TIM5Configuration
  * @����   ����TIM5�ж�������������
  * @����   ��
  * @����ֵ ��
***------------------------------------------------------*/
//static void NVIC_TIM2Enbale(void)
//{ 
//    NVIC_InitTypeDef NVIC_InitStructure;

//    /* Set the Vector Table base address at 0x08000000 */
//    //NVIC_SetVectorTable(NVIC_VectTab_FLASH, 0x0000);

//    /* Enable the TIM5 gloabal Interrupt */
//    NVIC_InitStructure.NVIC_IRQChannel =  TIM2_IRQn;
//    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;
//    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
//    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
//    NVIC_Init(&NVIC_InitStructure);
//}


/**-------------------------------------------------------
  * @������ NVIC_TIM5Configuration
  * @����   ����TIM5�ж�������������
  * @����   ��
  * @����ֵ ��
***------------------------------------------------------*/
void NVIC_TIM2Disbale(void)
{ 
    NVIC_InitTypeDef NVIC_InitStructure;
    /* Set the Vector Table base address at 0x08000000 */
    //NVIC_SetVectorTable(NVIC_VectTab_FLASH, 0x0000);

    /* Enable the TIM2 gloabal Interrupt */
    NVIC_InitStructure.NVIC_IRQChannel =  TIM2_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
    NVIC_InitStructure.NVIC_IRQChannelCmd = DISABLE;
    NVIC_Init(&NVIC_InitStructure);
}




/**-------------------------------------------------------
  * @������ NVIC_TIM5Configuration
  * @����   ����TIM5�ж�������������
  * @����   ��
  * @����ֵ ��
***------------------------------------------------------*/
void NVIC_TIM3Enbale(void)
{ 
    NVIC_InitTypeDef NVIC_InitStructure;

    /* Set the Vector Table base address at 0x08000000 */
    //NVIC_SetVectorTable(NVIC_VectTab_FLASH, 0x0000);

    /* Enable the TIM5 gloabal Interrupt */
    NVIC_InitStructure.NVIC_IRQChannel =  TIM3_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 3;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 3;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure);
}


/**-------------------------------------------------------
  * @������ NVIC_TIM5Configuration
  * @����   ����TIM5�ж�������������
  * @����   ��
  * @����ֵ ��
***------------------------------------------------------*/
//void NVIC_TIM3Disbale(void)
//{ 
//    NVIC_InitTypeDef NVIC_InitStructure;
//    /* Set the Vector Table base address at 0x08000000 */
//    //NVIC_SetVectorTable(NVIC_VectTab_FLASH, 0x0000);

//    /* Enable the TIM2 gloabal Interrupt */
//    NVIC_InitStructure.NVIC_IRQChannel =  TIM3_IRQn;
//    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 3;
//    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 3;
//    NVIC_InitStructure.NVIC_IRQChannelCmd = DISABLE;
//    NVIC_Init(&NVIC_InitStructure);
//}


/**-------------------------------------------------------
  * @������ NVIC_TIM5Configuration
  * @����   ����TIM5�ж�������������
  * @����   ��
  * @����ֵ ��
***------------------------------------------------------*/
//static void NVIC_TIM4Enbale(void)
//{ 
//    NVIC_InitTypeDef NVIC_InitStructure;

//    /* Set the Vector Table base address at 0x08000000 */
//    //NVIC_SetVectorTable(NVIC_VectTab_FLASH, 0x0000);

//    /* Enable the TIM5 gloabal Interrupt */
//    NVIC_InitStructure.NVIC_IRQChannel =  TIM4_IRQn;
//    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 3;
//    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 2;
//    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
//    NVIC_Init(&NVIC_InitStructure);
//}


/**-------------------------------------------------------
  * @������ NVIC_TIM5Configuration
  * @����   ����TIM5�ж�������������
  * @����   ��
  * @����ֵ ��
***------------------------------------------------------*/
void NVIC_TIM4Disbale(void)
{ 
    NVIC_InitTypeDef NVIC_InitStructure;
    /* Set the Vector Table base address at 0x08000000 */
    //NVIC_SetVectorTable(NVIC_VectTab_FLASH, 0x0000);

    /* Enable the TIM2 gloabal Interrupt */
    NVIC_InitStructure.NVIC_IRQChannel =  TIM4_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 3;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 2;
    NVIC_InitStructure.NVIC_IRQChannelCmd = DISABLE;
    NVIC_Init(&NVIC_InitStructure);
}

