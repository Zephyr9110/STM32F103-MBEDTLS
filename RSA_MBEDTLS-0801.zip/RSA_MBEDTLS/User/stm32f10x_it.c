/**
  ******************************************************************************
  * @file    Project/STM32F10x_StdPeriph_Template/stm32f10x_it.c 
  * @author  MCD Application Team
  * @version V3.3.0
  * @date    04/16/2010
  * @brief   Main Interrupt Service Routines.
  *          This file provides template for all exceptions handler and 
  *          peripherals interrupt service routine.
  ******************************************************************************
  * @copy
  *
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, STMICROELECTRONICS SHALL NOT BE HELD LIABLE FOR ANY
  * DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  * <h2><center>&copy; COPYRIGHT 2010 STMicroelectronics</center></h2>



*/ 




/* Includes ------------------------------------------------------------------*/
#include "stm32f10x_it.h"
#include "stm32f10x_tim.h"
#include "main.h"
#include "timer3.h"
 #include "stm32f10x_wwdg.h"
 #include "stm32f10x_rtc.h"
#include "can.h"



/** @addtogroup STM32F10x_StdPeriph_Template
  * @{
  */

/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
/* Private function prototypes -----------------------------------------------*/
/* Private functions ---------------------------------------------------------*/

/******************************************************************************/
/*            Cortex-M3 Processor Exceptions Handlers                         */
/******************************************************************************/

/**
  * @brief   This function handles NMI exception.
  * @param  None
  * @retval None
  */
void NMI_Handler(void)
{
}
void WaitNop_IT()
{
    for(uint32_t i = 0;i < 1250000; i ++)
    {
        __NOP();  
    }
}
/**
  * @brief  This function handles Hard Fault exception.
  * @param  None
  * @retval None
  */
void HardFault_Handler(void)
{
	printf("�ź��жϲ���δͨ��\r\n");
	/* Go to infinite loop when Hard Fault exception occurs */
	while (1)
	{

	printf("hard fault\r\n");
	//	  //>> ��ʾ���
	//		for(uint8_t i = 0;i < LED_NUM;i ++) {
	//			LedSetColor(i,3,0);
	//		}
	//		WaitNop_IT();
	}
}

/**
  * @brief  This function handles Memory Manage exception.
  * @param  None
  * @retval None
  */
void MemManage_Handler(void)
{
  /* Go to infinite loop when Memory Manage exception occurs */
  while (1)
  {
	  printf("memanage fault\r\n");
  }
}

/**
  * @brief  This function handles Bus Fault exception.
  * @param  None
  * @retval None
  */
void BusFault_Handler(void)
{
  /* Go to infinite loop when Bus Fault exception occurs */
  while (1)
  {
	  printf("busfault fault\r\n");
  }
}

/**
  * @brief  This function handles Usage Fault exception.
  * @param  None
  * @retval None
  */
void UsageFault_Handler(void)
{
  /* Go to infinite loop when Usage Fault exception occurs */
  while (1)
  {
	   printf("busfault fault\r\n");
  }
}

/**
  * @brief  This function handles SVCall exception.
  * @param  None
  * @retval None
  */
void SVC_Handler(void)
{
}

/**
  * @brief  This function handles Debug Monitor exception.
  * @param  None
  * @retval None
  */
void DebugMon_Handler(void)
{
}

/**
  * @brief  This function handles PendSVC exception.
  * @param  None
  * @retval None
  */
void PendSV_Handler(void)
{
}

/**
  * @brief  This function handles SysTick Handler.
  * @param  None
  * @retval None
  */
void SysTick_Handler(void)
{
	//IncrementMsCount();
	TimingDelay_Decrement();
}
/**-------------------------------------------------------
  * @������ EXTI15_10_IRQHandler
  * @����   �����ⲿ�ж���10-15���жϣ�����2��3�жϴ�������
  * @����   ��
  * @����ֵ ��
***------------------------------------------------------
void EXTI15_10_IRQHandler(void) 
{
    if(EXTI_GetITStatus(EXTI_Line15) != RESET)
    {
      DelayMs(50);
			if(0 == GPIO_ReadInputDataBit(GPIOC, GPIO_Pin_15))
			{
			//	printf("\n\r  This is Exti_15 interrupt!\n\r");
				printf("\n\r  This is K3 interrupt!\n\r");
			}
			while(0 == GPIO_ReadInputDataBit(GPIOC, GPIO_Pin_15))
			DelayMs(50);
			EXTI_ClearITPendingBit(EXTI_Line15);
    }
}*/
    u32 counter = 0;
/**-------------------------------------------------------
  * @������ TIM2_IRQHandler
  * @����   TIM2�жϴ���������ÿ���ж�һ�� 
  * @����   ��
  * @����ֵ ��
***------------------------------------------------------*/
void TIM2_IRQHandler(void)
{
   //static u32 counter = 1;
	int i;
	 if (TIM_GetITStatus(TIM2, TIM_IT_Update) != RESET)
    {
        TIM_ClearITPendingBit(TIM2, TIM_IT_Update);
        NVIC_TIM2Disbale();		
		Tim3Int_Enable();
        //printf("TIM2�жϴ���: %d\n\r", counter);
				if((counter%2)==0)
					GPIO_ResetBits(GPIOB,GPIO_Pin_1);
				else
					GPIO_SetBits(GPIOB,GPIO_Pin_1);
				counter++;
				  for(i=0;i<0xfffff;i++);

//				if(counter==10)
//				{
//					NVIC_TIM2Disbale();
//					counter=1;
//			  	ResetTimerFlg();	
//				}				
    }
}

/**-------------------------------------------------------
  * @������ TIM2_IRQHandler
  * @����   TIM2�жϴ���������ÿ���ж�һ�� 
  * @����   ��
  * @����ֵ ��
***------------------------------------------------------*/
u8 color1 = 1;
uint8_t test_data[8] = {0x11,0x11,0x11,0x11,0x11,0x11,0x11,0x11};
uint16_t CanSendCnt = 0;
uint8_t ret = 0;
void TIM3_IRQHandler(void)
{
	counter++;
	if (TIM_GetITStatus(TIM3, TIM_IT_Update) != RESET)
	{
		if(Time3SetFlag == 1 ) 
		{
			TIM_ClearITPendingBit(TIM3, TIM_IT_Update);
			if( RevDone == 3)
			{
				printf("Inter tim3 interrupt\r\n");
				ret = CAN_Send_Msg(0, 0x01, test_data, 8, 1);
				if(ret == CAN_OK)		
				{
					printf("can send times ok: %d\r\n",CanSendCnt ++);
				}	
				else if(ret == CAN_NOT_OK)
				{
					printf("can send times not ok: %d\r\n",CanSendCnt ++);
				}
				else
				{
					printf("can send times busy: %d\r\n",CanSendCnt ++);
				}
				test_data[7] += 1;
				RevDone = 0;
			}				
		}
		else
		{
			//TIM_Cmd(TIM3,DISABLE);
			NVIC->ICER[TIM3_IRQn >> 0x05] = (uint32_t)0x01 << (TIM3_IRQn & (uint8_t)0x1F);
			TIM_ClearITPendingBit(TIM3, TIM_IT_Update);  	
			//TIM3->SR = 0;			
			//printf("TIM3___it�жϴ���: %d\r\n", counter);
			//>>����ն�������rgb���ڴ����У�ѭ����ʾ������������쳣��������ڴ����ﵽ֮ǰ�ͽ���hardfault���ƹⳣ�̡�
			if(counter > 500)
			{
				printf("TIM3����ͨ��\r\n");
				for(uint8_t i = 0;i < LED_NUM;i ++) 
				{
					LedSetColor(i,color1,50);
				}
				color1 ++;
				if(color1 > 3) {
					color1 = 1;
				}
				//CAN_Send_Msg(0, 0x01, test_data, 8, 1);
				WaitNop_IT();
			}
			NVIC_TIM3Enbale();
		}

	}
}

/**-------------------------------------------------------
  * @������ TIM2_IRQHandler
  * @����   TIM2�жϴ���������ÿ���ж�һ�� 
  * @����   ��
  * @����ֵ ��
***------------------------------------------------------*/
uint32_t Timer4_IntUs = 0;
void TIM4_IRQHandler(void)
{
	if (TIM_GetITStatus(TIM4, TIM_IT_Update) != RESET)
    {
        TIM_ClearITPendingBit(TIM4, TIM_IT_Update);	
		Timer4_IntUs ++;

    }
}


#ifdef WEIDU_TEST
/**
  * @brief  This function handles USB Low Priority or CAN RX0 interrupts 
  *   requests.
  * @param  None
  * @retval : None
  */
void USB_LP_CAN1_RX0_IRQHandler(void)
{
  extern __IO uint32_t Result; /* for return of the interrupt handling */
  CanRxMsg RxMessage;

  RxMessage.StdId=0x00;
  RxMessage.ExtId=0x00;
  RxMessage.IDE=0;
  RxMessage.DLC=0;
  RxMessage.FMI=0;
  RxMessage.Data[0]=0x00;
  RxMessage.Data[1]=0x00;

  CAN_Receive(CAN1, CAN_FIFO0, &RxMessage);

  if((RxMessage.ExtId==0x1234) && (RxMessage.IDE==CAN_ID_EXT)
     && (RxMessage.DLC==2) && ((RxMessage.Data[1]|RxMessage.Data[0]<<8)==0xDECA))
  {
    Result = 1; 
  }
  else
  {
    Result = 0; 
  }
}
#endif







/******************************************************************************/
/*                 STM32F10x Peripherals Interrupt Handlers                   */
/*  Add here the Interrupt Handler for the used peripheral(s) (PPP), for the  */
/*  available peripheral interrupt handler's name please refer to the startup */
/*  file (startup_stm32f10x_xx.s).                                            */
/******************************************************************************/

/**
  * @brief  This function handles PPP interrupt request.
  * @param  None
  * @retval None
  */
/*void PPP_IRQHandler(void)
{
}*/

/**
  * @}
  */ 


/******************* (C) COPYRIGHT 2010 STMicroelectronics *****END OF FILE****/
