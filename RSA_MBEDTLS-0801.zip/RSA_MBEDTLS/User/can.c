#include "can.h"
//#include "led.h"
//#include "usart.h"
#include "string.h"
#include "main.h"
#define CAN_DEBUG

#define DEBUG_ID_MASK 0x80000000

enum {NOTACK=0, CAN1_OK, CAN2_OK}; 

#define READ_REG(REG)         ((REG))
#define CAN_TSR_CODE_Pos (24U)

#define FIFO_LEN 3
#define MB_LEN 3

typedef struct msg_buff
{
	uint8_t front;
	uint8_t rear;
	uint8_t msg_total;
	uint8_t valid[FIFO_LEN]; 
	uint16_t msg_seq[FIFO_LEN]; 
	CanTxMsg msg_fifo[FIFO_LEN];
}msg_buff_t;

#ifdef CAN_DEBUG
typedef struct info_buff{
	uint32_t bk_id;
	uint16_t bk_seq;	
}info_buff_t;

uint32_t send_data_resend_cnt=0;
uint32_t send_data_resend1_getnul_cnt;
uint32_t send_data_resend2_getnul_cnt;

uint32_t send_data_resend_get_cnt;

uint32_t send_data_busy_cnt=0;
uint32_t send_data_call_cnt=0;
uint32_t send_data_cnt=0;
uint32_t send_data_cpy_cnt=0;
uint32_t send_data_recpy_cnt=0;
uint32_t send_data_ok_cnt=0;

uint32_t tx1_lst_num;
uint32_t tx1_abort_num;
uint32_t tx1_err_num;
uint32_t tx2_lst_num;
uint32_t tx2_abort_num;
uint32_t tx2_err_num;

uint32_t tx_resend_notok_num;

uint32_t isr_err_num;
uint32_t isr_num;
uint32_t isr1_num;
uint32_t isr2_num;

uint32_t confirmation_err_id_num;
uint32_t confirmation_call_num;
uint32_t confirmation_num;
uint32_t confirmation1_null_num;
uint32_t confirmation2_null_num;

uint32_t fifo1_clear_num;
uint32_t fifo2_clear_num;

uint32_t not_match_cnt;
uint32_t not_confirmation_cnt = 0;

uint32_t sce_num;
uint32_t busoff_num;
uint32_t start_num;

uint32_t can1_tsr_bk;
uint32_t can11_tsr_bk;
uint32_t can2_tsr_bk;
uint32_t can22_tsr_bk;

uint32_t can2201_tsr_bk;
uint32_t can2202_tsr_bk;
uint32_t transmitmailbox_bk;

uint32_t tsr1flags;
uint32_t tsr2flags;

uint8_t lost_flag = 0;

#endif

CanTxMsg TxMessage_resend;
uint16_t CanTxMsg_resend_seq;

uint32_t Receive_flag = 0;
#if 1
msg_buff_t CAN1_buff_mb[3];
msg_buff_t CAN2_buff_mb[3];
#else
msg_buff_t CAN_buff_mb[3];
#endif

Can_ReturnType CAN_Send_Msg_second(uint8_t Controller);
uint8_t CAN_Send_Msg_Resend(uint32_t transmitmailbox, CAN_TypeDef * can_x);
uint8_t CAN_Send_Msg_Confirmation(uint32_t transmitmailbox, CAN_TypeDef* CANx);
void CAN_Send_Msg_Abort(CAN_TypeDef * can_x, uint32_t transmitmailbox);
void CAN_TX_IRQHandler(uint32_t tsrflags, CAN_TypeDef * can_x);




#ifdef CAN_DEBUG
void debug_gpio_init(void)
{

}
#endif

void loop_err(void)
{
    while(1);
}

void init_msg_fifo(uint8_t canx)
{
	uint8_t mb_i;
	if(canx == 0){
		for(mb_i=0; mb_i<MB_LEN; mb_i++)
		{
#ifdef CAN_DEBUG
			fifo1_clear_num += CAN1_buff_mb[mb_i].msg_total;
#endif
			CAN1_buff_mb[mb_i].front = 0;
			CAN1_buff_mb[mb_i].rear = 0;
			CAN1_buff_mb[mb_i].msg_total = 0;
		}
	}else if(canx == 1){
		for(mb_i=0; mb_i<MB_LEN; mb_i++)
		{
#ifdef CAN_DEBUG
			fifo2_clear_num += CAN2_buff_mb[mb_i].msg_total;
#endif
			CAN2_buff_mb[mb_i].front = 0;
			CAN2_buff_mb[mb_i].rear = 0;
			CAN2_buff_mb[mb_i].msg_total = 0;
		}
	}else{
		for(mb_i=0; mb_i<MB_LEN; mb_i++)
		{
#ifdef CAN_DEBUG
			fifo1_clear_num += CAN1_buff_mb[mb_i].msg_total;
#endif
			CAN1_buff_mb[mb_i].front = 0;
			CAN1_buff_mb[mb_i].rear = 0;
			CAN1_buff_mb[mb_i].msg_total = 0;
#ifdef CAN_DEBUG			
			fifo2_clear_num += CAN2_buff_mb[mb_i].msg_total;
#endif
			CAN2_buff_mb[mb_i].front = 0;
			CAN2_buff_mb[mb_i].rear = 0;
			CAN2_buff_mb[mb_i].msg_total = 0;
		}
	}
	
}
#if 0
uint8_t get_msg_fifo_max_len(uint8_t can_if)
{
	uint8_t mb_i,ret=0;
	uint8_t max_len=0;

	if(can_if == 0){
		for(mb_i=0; mb_i<MB_LEN; mb_i++)
		{
			if(max_len <= CAN1_buff_mb[mb_i].msg_total){
				max_len = CAN1_buff_mb[mb_i].msg_total;
			}
		}
	}else{
		for(mb_i=0; mb_i<MB_LEN; mb_i++)
		{
			if(max_len <= CAN2_buff_mb[mb_i].msg_total){
				max_len = CAN2_buff_mb[mb_i].msg_total;
			}
		}
	}
	return max_len;	
}
#else
#define MAIL_CNT_MAX 3
uint8_t can1_mail_cnt;
uint8_t can2_mail_cnt;

int8_t mail10;
int8_t mail11;
int8_t mail12;
int8_t mail20;
int8_t mail21;
int8_t mail22;

int8_t mail_flag = 0;

uint8_t get_msg_fifo_max_len(uint8_t can_if)
{
	return 0;
}
#endif

void CAN_Busoff(uint8_t ControllerID)
{   
//   (void)Can_SetControllerMode(ControllerID, CAN_T_STOP);
//    CanIf_ControllerBusOff(ControllerID);
}

#if 0
uint8_t put_msg_fifo(uint8_t mbid, msg_buff_t (*CAN_buff_p)[], CanTxMsg *msg_p, uint16_t msg_seq)
{
	uint8_t ret=0;
	uint8_t *ptr_a;
	msg_buff_t (*CAN_buff_mb)[];
	CAN_buff_mb = CAN_buff_p;

	if((*CAN_buff_mb + mbid)->msg_total < FIFO_LEN){
		ptr_a = (uint8_t*)&((*CAN_buff_mb + mbid)->msg_fifo[(*CAN_buff_mb + mbid)->front]);

		for(uint8_t cnt=0; cnt<sizeof(CanTxMsg); cnt++)
		{				
			*(ptr_a + cnt) = *((uint8_t*)msg_p + cnt);
		}

		(*CAN_buff_mb + mbid)->msg_seq[(*CAN_buff_mb + mbid)->front] = msg_seq;

		(*CAN_buff_mb + mbid)->front++;

		if((*CAN_buff_mb + mbid)->front == FIFO_LEN){
			(*CAN_buff_mb + mbid)->front = 0;
		}

		(*CAN_buff_mb + mbid)->msg_total++;
		ret = 0;

	}else{
		ret = 1;
	}
	return ret;
}

uint8_t get_msg_fifo(uint8_t mbid, msg_buff_t (*CAN_buff_p)[], CanTxMsg *msg_p, uint16_t *msg_seq)
{
	uint8_t ret=0;
	uint8_t *ptr_a;
	msg_buff_t (*CAN_buff_mb)[];
	CAN_buff_mb = CAN_buff_p;

	if((*CAN_buff_mb + mbid)->msg_total > 0){
		if(msg_p != NULL){
			ptr_a = (uint8_t*)&((*CAN_buff_mb + mbid)->msg_fifo[(*CAN_buff_mb + mbid)->rear]);
			for(uint8_t cnt=0; cnt<sizeof(CanTxMsg); cnt++)
			{				
				*((uint8_t*)msg_p + cnt) = *((uint8_t*)ptr_a + cnt);
			}			
		}		

		*msg_seq = (*CAN_buff_mb + mbid)->msg_seq[(*CAN_buff_mb + mbid)->rear];

		(*CAN_buff_mb + mbid)->rear++;

		if((*CAN_buff_mb + mbid)->rear == FIFO_LEN){
			(*CAN_buff_mb + mbid)->rear = 0;
		}

		(*CAN_buff_mb + mbid)->msg_total--;
		ret = 0;
	}else{
		ret = 1;
	}
	return ret;
}
#else

uint8_t put_can1_msg_fifo(uint8_t mbid, CanTxMsg *msg_p, uint16_t msg_seq)
{
	uint8_t ret=0;
	uint8_t *ptr_a;
	if(CAN1_buff_mb[mbid].msg_total < FIFO_LEN){
		ptr_a = (uint8_t*)&(CAN1_buff_mb[mbid].msg_fifo[CAN1_buff_mb[mbid].front]);
		for(uint8_t cnt=0; cnt<sizeof(CanTxMsg); cnt++)
		{				
			*(ptr_a + cnt) = *((uint8_t*)msg_p + cnt);
		}

		CAN1_buff_mb[mbid].msg_seq[CAN1_buff_mb[mbid].front] = msg_seq;

		CAN1_buff_mb[mbid].front++;
		if(CAN1_buff_mb[mbid].front == FIFO_LEN){
			CAN1_buff_mb[mbid].front = 0;
		}

		CAN1_buff_mb[mbid].msg_total++;
		ret = 0;
	}else{
		ret = 1;
	}
	return ret;
}

uint8_t put_can2_msg_fifo(uint8_t mbid, CanTxMsg *msg_p, uint16_t msg_seq)
{
	uint8_t ret=0;
	uint8_t *ptr_a;
	if(CAN2_buff_mb[mbid].msg_total < FIFO_LEN){
		ptr_a = (uint8_t*)&(CAN2_buff_mb[mbid].msg_fifo[CAN2_buff_mb[mbid].front]);
		for(uint8_t cnt=0; cnt<sizeof(CanTxMsg); cnt++)
		{				
			*(ptr_a + cnt) = *((uint8_t*)msg_p + cnt);
		}

		CAN2_buff_mb[mbid].msg_seq[CAN2_buff_mb[mbid].front] = msg_seq;

		CAN2_buff_mb[mbid].front++;
		if(CAN2_buff_mb[mbid].front == FIFO_LEN){
			CAN2_buff_mb[mbid].front = 0;
		}

		CAN2_buff_mb[mbid].msg_total++;
		ret = 0;
	}else{
		ret = 1;
	}
	return ret;
}

uint8_t get_can1_msg_fifo(uint8_t mbid, CanTxMsg *msg_p, uint16_t *msg_seq)
{
	uint8_t ret=0;
	uint8_t *ptr_a;

	if(CAN1_buff_mb[mbid].msg_total > 0){

		if(msg_p != NULL){			
			ptr_a = (uint8_t*)&CAN1_buff_mb[mbid].msg_fifo[CAN1_buff_mb[mbid].rear];
#if 1			
			memcpy(msg_p, ptr_a, sizeof(CanTxMsg));
#else
			for(uint8_t cnt=0; cnt<sizeof(CanTxMsg); cnt++)
			{				
				*((uint8_t*)msg_p + cnt) = *((uint8_t*)ptr_a + cnt);
			}
#endif
		}

		*msg_seq = CAN1_buff_mb[mbid].msg_seq[CAN1_buff_mb[mbid].rear];

		CAN1_buff_mb[mbid].rear++;
		if(CAN1_buff_mb[mbid].rear == FIFO_LEN){
			CAN1_buff_mb[mbid].rear = 0;
		}

		CAN1_buff_mb[mbid].msg_total--;
		ret = 0;
	}else{
//		loop_err();
		ret = 1;
	}
	return ret;
}

uint8_t get_can2_msg_fifo(uint8_t mbid, CanTxMsg *msg_p, uint16_t *msg_seq)
{
	uint8_t ret=0;
	uint8_t *ptr_a;

	if(CAN2_buff_mb[mbid].msg_total > 0){

		if(msg_p != NULL){
			
			ptr_a = (uint8_t*)&CAN2_buff_mb[mbid].msg_fifo[CAN2_buff_mb[mbid].rear];
#if 1
			memcpy(msg_p, ptr_a, sizeof(CanTxMsg));
#else		
			for(uint8_t cnt=0; cnt < sizeof(CanTxMsg); cnt++)
			{				
				*((uint8_t*)msg_p + cnt) = *((uint8_t*)ptr_a + cnt);
			}	
#endif
		}		

		*msg_seq = CAN2_buff_mb[mbid].msg_seq[CAN2_buff_mb[mbid].rear];

		CAN2_buff_mb[mbid].rear++;
		if(CAN2_buff_mb[mbid].rear == FIFO_LEN){
			CAN2_buff_mb[mbid].rear = 0;
		}
		
		CAN2_buff_mb[mbid].msg_total--;
		ret = 0;
	}else{
		loop_err();
		ret = 1;
	}
	return ret;
}
#endif

void busoff_rst_can(CAN_TypeDef *CANx)
{
	uint8_t mb_i = 0;
	uint8_t can_i;
	if(CANx == CAN1){
		can_i = 0; 	
		can1_mail_cnt = 0;
	}else if(CANx == CAN2){
		can_i = 1;
		can2_mail_cnt = 0;
	}else{
		can_i = 2;
	}

	for(mb_i = 0 ; mb_i < MB_LEN; mb_i++)
	{
		CAN_Send_Msg_Abort(CANx, mb_i);
	}

	init_msg_fifo(can_i);

	CAN_ClearITPendingBit(CANx,CAN_IT_TME);
}


u8 can1_init(u8 tsjw,u8 tbs1,u8 tbs2,u16 brp,u8 mode)
{
	GPIO_InitTypeDef GPIO_InitStructure; 
	CAN_InitTypeDef  CAN_InitStructure;
//	CAN_FilterInitTypeDef  CAN_FilterInitStructure;
	NVIC_InitTypeDef  NVIC_InitStructure;
#if 1
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);  
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);  	
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_CAN1, ENABLE);

	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_11;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;	
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
	GPIO_Init(GPIOA, &GPIO_InitStructure);

	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_12;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;	
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
	GPIO_Init(GPIOA, &GPIO_InitStructure);
	
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_11;				 
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP; 		 
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;		 
	GPIO_Init(GPIOB, &GPIO_InitStructure);	

	//GPIO_ResetBits(GPIOB,GPIO_Pin_0);
	GPIO_ResetBits(GPIOB,GPIO_Pin_11);
#else
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE); 																			 
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_CAN1, ENABLE);

	GPIO_PinRemapConfig(GPIO_Remap1_CAN1, ENABLE);

	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_8;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz; 
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
	GPIO_Init(GPIOB, &GPIO_InitStructure);

	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_9;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz; 
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
	GPIO_Init(GPIOB, &GPIO_InitStructure);

#endif
	CAN_DeInit(CAN1);
	  
	CAN_InitStructure.CAN_TTCM=DISABLE;	
	CAN_InitStructure.CAN_ABOM=ENABLE;//ENABLE;
	CAN_InitStructure.CAN_AWUM=DISABLE;
	CAN_InitStructure.CAN_NART=DISABLE;	//ENABLE;
	CAN_InitStructure.CAN_RFLM=DISABLE;	
//	CAN_InitStructure.CAN_TXFP=DISABLE;	
	CAN_InitStructure.CAN_TXFP=DISABLE;
	CAN_InitStructure.CAN_Mode= CAN_Mode_Normal;	 
	CAN_InitStructure.CAN_SJW=CAN_SJW_1tq;	
	CAN_InitStructure.CAN_BS1=CAN_BS1_9tq; 
	CAN_InitStructure.CAN_BS2=CAN_BS2_8tq;
//        	CAN_InitStructure.CAN_BS1=CAN_BS1_7tq; 
//	CAN_InitStructure.CAN_BS2=CAN_BS2_2tq;
	CAN_InitStructure.CAN_Prescaler=4;
	CAN_Init(CAN1, &CAN_InitStructure);

//	CAN_DBGFreeze(CAN1, ENABLE);// add debug frozen

	// CAN_FilterInitStructure.CAN_FilterNumber=0;	  
	// CAN_FilterInitStructure.CAN_FilterMode=CAN_FilterMode_IdList; 
	// CAN_FilterInitStructure.CAN_FilterScale=CAN_FilterScale_32bit;

	// CAN_FilterInitStructure.CAN_FilterIdHigh=(((0x00000111)>>13)&0xffff);
	// CAN_FilterInitStructure.CAN_FilterIdLow=(((((uint32_t)0x00000111)<<3)|(0x00000004))&0xffff);

	// CAN_FilterInitStructure.CAN_FilterMaskIdHigh=(((0x13333333)>>13)&0xffff);
	// CAN_FilterInitStructure.CAN_FilterMaskIdLow=(((((uint32_t)0x13333333)<<3)|(0x00000004))&0xffff);

	// CAN_FilterInitStructure.CAN_FilterFIFOAssignment=CAN_Filter_FIFO0;
	// CAN_FilterInitStructure.CAN_FilterActivation=ENABLE; 
	// CAN_FilterInit(&CAN_FilterInitStructure);  
	
	CAN_ITConfig(CAN1,CAN_IT_FMP0,ENABLE);	    

	NVIC_InitStructure.NVIC_IRQChannel = USB_LP_CAN1_RX0_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 2;     
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;           
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_Init(&NVIC_InitStructure);

	CAN_ITConfig(CAN1,CAN_IT_TME,ENABLE);   
  
	NVIC_InitStructure.NVIC_IRQChannel = USB_HP_CAN1_TX_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;     
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;           
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_Init(&NVIC_InitStructure);

	CAN_ITConfig(CAN1,CAN_IT_BOF,ENABLE);    

	NVIC_InitStructure.NVIC_IRQChannel = CAN1_SCE_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0; 
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0; 
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_Init(&NVIC_InitStructure);

	CAN_ITConfig(CAN1,CAN_IT_ERR,ENABLE);   

	NVIC_InitStructure.NVIC_IRQChannel = CAN1_SCE_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_Init(&NVIC_InitStructure);
  
  CAN_OperatingModeRequest(CAN1,CAN_OperatingMode_Normal);

	return 0;
}   

void can1_config(void)
{
	init_msg_fifo(0);
	CAN_FilterSet();
}
#ifdef RSA_TEST
void USB_LP_CAN1_RX0_IRQHandler(void)
{
	CanRxMsg RxMessage;
	CAN_Receive(CAN1, CAN_Filter_FIFO0, &RxMessage);
	Can_Canif_Receive(CAN_CONTROLLER1,&RxMessage);
	Receive_flag = 1;
}
#endif
void USB_HP_CAN1_TX_IRQHandler(void)
{
	tsr1flags = READ_REG(CAN1->TSR);
#if 0
	CAN_ClearITPendingBit(CAN1, CAN_IT_TME);
#else
	if((tsr1flags & CAN_TSR_RQCP0) == CAN_TSR_RQCP0){
		CAN1->TSR |= CAN_TSR_RQCP0;
	}
	if((tsr1flags & CAN_TSR_RQCP1) == CAN_TSR_RQCP1){
		CAN1->TSR |= CAN_TSR_RQCP1;
	}
	if((tsr1flags & CAN_TSR_RQCP2) == CAN_TSR_RQCP2){
		CAN1->TSR |= CAN_TSR_RQCP2;
	}
#endif
	isr1_num++;
	CAN_TX_IRQHandler(tsr1flags, CAN1);
}

void CAN_TX_IRQHandler(uint32_t tsrflags, CAN_TypeDef * can_x)
{
	CAN_TypeDef* CANx;
	CANx = can_x;
	
#ifdef CAN_DEBUG
	isr_num++;
#endif

	uint32_t interrupts = READ_REG(CANx->IER);
	
	if ((interrupts & CAN_IER_TMEIE) != 0U){
		if ((tsrflags & CAN_TSR_RQCP0) != 0U){			
			if ((tsrflags & CAN_TSR_TXOK0) != 0U){
				send_data_ok_cnt++;
				if(lost_flag == 1){
					lost_flag = 2;
				}
				CAN_Send_Msg_Confirmation(0, can_x);		
				
			}else{
				loop_err();
				if ((tsrflags & CAN_TSR_ALST0) != 0U){ //lost
#ifdef CAN_DEBUG				
					if(CANx == CAN1){
						tx1_lst_num++;
					}else{
						tx2_lst_num++;
					}
#endif					
					if(CAN_OK != CAN_Send_Msg_Resend(0, CANx)){
						tx_resend_notok_num++;
						loop_err();
					}
				}else if((tsrflags & CAN_TSR_TERR0) != 0U){//err
#ifdef CAN_DEBUG
					if(CANx == CAN1){
						tx1_err_num++;
					}else{
						tx2_err_num++;					
					}
#endif
					if(CAN_OK != CAN_Send_Msg_Resend(0, CANx)){
						tx_resend_notok_num++;
						loop_err();
					}
				}else{	//abort
#ifdef CAN_DEBUG
					if(CANx == CAN1){
						tx1_abort_num++;
					}else{
						tx2_abort_num++;
					}
#endif
					if(CAN_OK != CAN_Send_Msg_Resend(0, CANx)){
						tx_resend_notok_num++;
						loop_err();
					}
				}
			}
		}

		if ((tsrflags & CAN_TSR_RQCP1) != 0U){			
			if ((tsrflags & CAN_TSR_TXOK1) != 0U){
				send_data_ok_cnt++;
				CAN_Send_Msg_Confirmation(1, can_x);							
			}else{
				while(1);
				#if 0
				loop_err();
				if ((tsrflags & CAN_TSR_ALST1) != 0U){ 
#ifdef CAN_DEBUG
					if(CANx == CAN1)
						tx1_lst_num++;
					else
						tx2_lst_num++;
#endif	
					if(CAN_OK != CAN_Send_Msg_Resend(1, CANx)){
						tx_resend_notok_num++;
						loop_err();
					}
				}else if((tsrflags & CAN_TSR_TERR1) != 0U){
#ifdef CAN_DEBUG
					if(CANx == CAN1){
						tx1_err_num++;
					}else{
						tx2_err_num++;
					}
#endif
					if(CAN_OK != CAN_Send_Msg_Resend(1, CANx)){
						tx_resend_notok_num++;
						loop_err();
					}
				}else{	//abort
#ifdef CAN_DEBUG
					if(CANx == CAN1)
						tx1_abort_num++;
					else
						tx2_abort_num++;
#endif
					if(CAN_OK != CAN_Send_Msg_Resend(1, CANx)){
						tx_resend_notok_num++;
						loop_err();
					}
				}
				#endif
			}
		}

		if ((tsrflags & CAN_TSR_RQCP2) != 0U){			
			if ((tsrflags & CAN_TSR_TXOK2) != 0U){
				send_data_ok_cnt++;
				CAN_Send_Msg_Confirmation(2, can_x);							
			}else{
				while(1);
				#if 0
				loop_err();
				if ((tsrflags & CAN_TSR_ALST2) != 0U){ //lost
#ifdef CAN_DEBUG
					if(CANx == CAN1)
						tx1_lst_num++;
					else
						tx2_lst_num++;
#endif
					if(CAN_OK != CAN_Send_Msg_Resend(2, CANx)){
						loop_err();
					}
				}else if((tsrflags & CAN_TSR_TERR2) != 0U){//err
#ifdef CAN_DEBUG
					if(CANx == CAN1){
						tx1_err_num++;
					}else{
						tx2_err_num++;
					}
#endif
					if(CAN_OK != CAN_Send_Msg_Resend(2, CANx)){
						tx_resend_notok_num++;
						loop_err();
					}
				}else{	//abort
#ifdef CAN_DEBUG
					if(CANx == CAN1)
						tx1_abort_num++;
					else
						tx2_abort_num++;
#endif
					if(CAN_OK != CAN_Send_Msg_Resend(2, CANx)){
						tx_resend_notok_num++;
						loop_err();
					}
				}
				#endif
			}
		}
	}else{
#ifdef CAN_DEBUG
		isr_err_num++;
#endif
	}
}


void CAN2_TX_IRQHandler(void)
{
	tsr2flags = READ_REG(CAN2->TSR);
#if 0
	CAN_ClearITPendingBit(CAN2, CAN_IT_TME);
#else
	if((tsr2flags & CAN_TSR_RQCP0) == CAN_TSR_RQCP0){
		CAN2->TSR |= CAN_TSR_RQCP0;
	}
	if((tsr2flags & CAN_TSR_RQCP1) == CAN_TSR_RQCP1){
		CAN2->TSR |= CAN_TSR_RQCP1;
	}
	if((tsr2flags & CAN_TSR_RQCP2) == CAN_TSR_RQCP2){
		CAN2->TSR |= CAN_TSR_RQCP2;
	}
#endif
	isr2_num++;
	CAN_TX_IRQHandler(tsr2flags, CAN2);		
}

void CAN_SCE_IRQHandler(CAN_TypeDef * can_x)
{
#ifdef CAN_DEBUG
	sce_num++;
#endif
	if(CAN_GetITStatus(can_x,CAN_IT_BOF))
	{
#ifdef CAN_DEBUG
		busoff_num++;
#endif
		CAN_ClearITPendingBit(can_x, CAN_IT_ERR);
	
		busoff_rst_can(can_x);

	}else{
		CAN_ClearITPendingBit(can_x, CAN_IT_ERR);
	}	
}

void CAN1_SCE_IRQHandler(void)
{
	if((CAN1->ESR & CAN_ESR_BOFF) == CAN_ESR_BOFF){
		CAN1->TSR |= CAN_TSR_ABRQ0;
		CAN1->TSR |= CAN_TSR_ABRQ1;
		CAN1->TSR |= CAN_TSR_ABRQ2;
	}
	CAN_SCE_IRQHandler(CAN1);
}

void CAN2_SCE_IRQHandler(void)
{
	if((CAN2->ESR & CAN_ESR_BOFF) == CAN_ESR_BOFF){
		CAN2->TSR |= CAN_TSR_ABRQ0;
		CAN2->TSR |= CAN_TSR_ABRQ1;
		CAN2->TSR |= CAN_TSR_ABRQ2;
	}
	CAN_SCE_IRQHandler(CAN2);
}

uint32_t CAN_GetTxMailboxesFreeLevel(CAN_TypeDef* CANx)
{
	uint32_t freelevel = 0U;
	 /* Check Tx Mailbox 0 status */
	if ((CANx->TSR&CAN_TSR_TME0) == CAN_TSR_TME0){
		 freelevel++;
	 }

	 /* Check Tx Mailbox 1 status */
	if ((CANx->TSR&CAN_TSR_TME1) == CAN_TSR_TME1){
		 freelevel++;
	 }

	 /* Check Tx Mailbox 2 status */ 
	 if ((CANx->TSR&CAN_TSR_TME2) == CAN_TSR_TME2){
		 freelevel++;
	 }
	 /* Return Tx Mailboxes free level */
	 return freelevel;
}
uint32_t transmitmailbox_bk;
uint8_t mail20_bk;
uint8_t CAN_Send_Msg_Confirmation(uint32_t transmitmailbox, CAN_TypeDef* CANx)
{
	uint8_t ret = 0;
	assert_param(transmitmailbox < 3);
	uint16_t msg_seq = 0;
	CanTxMsg msg_get;
  if(mail20 == 3){
    loop_err();
  }
	confirmation_call_num++;

	uint32_t TXmsg_exid;
	TXmsg_exid = (CANx->sTxMailBox[transmitmailbox].TIR) >> 3;

	if(CANx == CAN1){
		if(0 != get_can1_msg_fifo(transmitmailbox, &msg_get, &msg_seq)){
			confirmation1_null_num++;
			loop_err();
			ret = CAN_NOT_OK;
		}
	}else if(CANx == CAN2){
		if(0 != get_can2_msg_fifo(transmitmailbox, &msg_get, &msg_seq)){
			confirmation2_null_num++;
			loop_err();
			ret = CAN_NOT_OK;
		}
	}else{
			loop_err();
	}

	if((CANx == CAN2)&&((msg_get.ExtId & (~DEBUG_ID_MASK)) != TXmsg_exid)){ 
      not_match_cnt++;
			loop_err();
	}

	if(CANx == CAN1){
		if(transmitmailbox == 0){
			mail10--;
		}else if(transmitmailbox == 1){
			mail11--;
		}else if(transmitmailbox == 2){
			mail12--;
		}else{
			loop_err();
		}
	}else{
		if(transmitmailbox == 0){
			mail20--;
		}else if(transmitmailbox == 1){
			mail21--;
		}else if(transmitmailbox == 2){
			mail22--;
		}else{
			loop_err();
		}
	}	
  
	if((mail_flag == 1)&&(mail10 == 0)&&(mail11 == 0)&&(mail12 == 0)&&(mail20 == 0)&&(mail21 == 0)&&(mail22 == 0)){
		loop_err();
	}	

	if(mail_flag == 1){
    loop_err();
		mail_flag = 0;
  }

	if((mail10 < 0)||(mail11 < 0)||(mail12 < 0)||(mail20 < 0)||(mail21 < 0)||(mail22 < 0)){
		loop_err();
	}
		
	if(CANx == CAN1){
		can1_mail_cnt--;
	}else{
		can2_mail_cnt--;
	}	
	confirmation_num++;

	return ret;
}

uint8_t CAN_Send_Msg(uint8_t Controller, uint32_t id, uint8_t* data,  uint8_t dlc, uint16_t seq)
{	
	Can_ReturnType  ret = CAN_BUSY;
	//uint8_t cnt;
	CAN_TypeDef *can_p;
	uint8_t transmitmailbox;
	//uint8_t* ptr_a,*ptr_b;
	uint16_t msg_seq = 0;

#ifdef CAN_DEBUG
	send_data_call_cnt++;
#endif

	if(Controller == CAN_CONTROLLER1){
		can_p = CAN1;
	}else{
		loop_err();	
	}

	CanTxMsg TxMessage;
	TxMessage.StdId=0x12;	   				
	TxMessage.ExtId=id; 				
	TxMessage.IDE=CAN_Id_Extended;		
	TxMessage.RTR=0;		  				
	TxMessage.DLC=dlc;

	memcpy(TxMessage.Data, data, dlc);

	transmitmailbox = CAN_Transmit(can_p, &TxMessage);

	if(transmitmailbox == CAN_TxStatus_NoMailBox){
		send_data_busy_cnt++;
		ret = CAN_BUSY;
	}else{

//	__disable_irq();	
	
		if(can_p == CAN1){
			can1_mail_cnt++;
			if(transmitmailbox == 0){
				mail10++;
				if(mail10 == 2){
					can1_tsr_bk = CAN1->TSR;
					get_can1_msg_fifo(transmitmailbox, NULL, &msg_seq);
          can11_tsr_bk = CAN1->TSR;
					not_confirmation_cnt++;
					mail10--;
				}
			}else if(transmitmailbox == 1){
				mail11++;
				if(mail11 == 2){
					get_can1_msg_fifo(transmitmailbox, NULL, &msg_seq);
					not_confirmation_cnt++;
					mail11--;
				}
			}else if(transmitmailbox == 2){
				mail12++;
				if(mail12 == 2){
					get_can1_msg_fifo(transmitmailbox, NULL, &msg_seq);
					not_confirmation_cnt++;
					mail12--;
				}
			}else{
				loop_err();
			}
		}else{
			can2_mail_cnt++;
			if(transmitmailbox == 0){				
				mail20++;
				if(mail20 == 2){
					can2_tsr_bk = CAN2->TSR;
					get_can2_msg_fifo(transmitmailbox, NULL, &msg_seq);
          can22_tsr_bk = CAN2->TSR;
					not_confirmation_cnt++;
					mail20--;
					lost_flag = 1;
				}
			}else if(transmitmailbox == 1){
				mail21++;
				if(mail21 == 2){
					get_can2_msg_fifo(transmitmailbox, NULL, &msg_seq);
					not_confirmation_cnt++;
					mail21--;
				}
			}else if(transmitmailbox == 2){
				mail22++;
				if(mail22 == 2){
					get_can2_msg_fifo(transmitmailbox, NULL, &msg_seq);
					not_confirmation_cnt++;
					mail22--;
				}
			}else{
				loop_err();
			}
		}

		if((mail10 == 2)||(mail11 == 2)||(mail12 == 2)||(mail20 == 2)||(mail21 == 2)||(mail22 == 2)){
			mail_flag = 1;
		}

		if((mail10 > 2)||(mail11 > 2)||(mail12 > 2)||(mail20 > 2)||(mail21 > 2)||(mail22 > 2)){
			loop_err();
		}
	
		if(can_p == CAN1){
			if(0 != put_can1_msg_fifo(transmitmailbox, &TxMessage , seq)){
				loop_err();
			}
		}else{
			if(0 != put_can2_msg_fifo(transmitmailbox, &TxMessage , seq)){
				loop_err();
			}
		}	
//		__enable_irq();
		send_data_cpy_cnt++;
		ret = CAN_OK;
	}	
  return ret;
}

uint8_t CAN_Send_Msg_Resend(uint32_t transmitmailbox, CAN_TypeDef * can_x)
{
	Can_ReturnType ret=CAN_BUSY;
	uint8_t transmitmailbox_resend;	
	CanTxMsg msg_get;
	uint16_t msg_seq;

	send_data_resend_cnt++;

	uint32_t TXmsg_exid;
	TXmsg_exid = (can_x->sTxMailBox[transmitmailbox].TIR) >> 3;

	if(can_x == CAN1){
		if(0 != get_can1_msg_fifo(transmitmailbox, &msg_get, &msg_seq)){
			send_data_resend1_getnul_cnt++;
			loop_err();
			return CAN_NOT_OK;
		}
	}else{
		if(0 != get_can2_msg_fifo(transmitmailbox, &msg_get, &msg_seq)){
			send_data_resend2_getnul_cnt++;
			loop_err();
			return CAN_NOT_OK;
		}
	} 

	if(msg_get.ExtId != (TXmsg_exid|DEBUG_ID_MASK)){
		loop_err();
	}


	if(can_x == CAN1){
		can1_mail_cnt--;
		if(transmitmailbox == 0){
			mail10--;
		}else if(transmitmailbox == 1){
			mail11--;
		}else if(transmitmailbox == 2){
			mail12--;
		}else{
			loop_err();
		}
	}else{
		can2_mail_cnt--;
		if(transmitmailbox == 0){
			mail20--;
		}else if(transmitmailbox == 1){
			mail21--;
		}else if(transmitmailbox == 2){
			mail22--;
		}else{
			loop_err();
		}
	}

	if((mail10 < 0)||(mail11 < 0)||(mail12 < 0)||(mail20 < 0)||(mail21 < 0)||(mail22 < 0)){
		loop_err();
	}		

	send_data_resend_get_cnt++;


	transmitmailbox_resend = CAN_Transmit(can_x, &msg_get);
	if(transmitmailbox_resend == CAN_TxStatus_NoMailBox){
		ret = CAN_BUSY;
		loop_err();
	}else{

		if(can_x == CAN1){
			if(0 != put_can1_msg_fifo(transmitmailbox_resend, &msg_get, msg_seq)){
				loop_err();
			}
		}else{
			if(0 != put_can2_msg_fifo(transmitmailbox_resend, &msg_get, msg_seq)){
				loop_err();
			}
		}

#ifdef CAN_DEBUG
		if(can_x == CAN1){
			can1_mail_cnt++;
			if(transmitmailbox_resend == 0){
				mail10++;
			}else if(transmitmailbox_resend == 1){
				mail11++;
			}else if(transmitmailbox_resend == 2){
				mail12++;
			}else{
				loop_err();
			}
		}else{
			can2_mail_cnt++;
			if(transmitmailbox_resend == 0){
				mail20++;
			}else if(transmitmailbox_resend == 1){
				mail21++;
			}else if(transmitmailbox_resend == 2){
				mail22++;
			}else{
				loop_err();
			}
		}	
		send_data_recpy_cnt++;	
#endif
		ret = CAN_OK;
	}
  return ret;
}

void CAN_Send_Msg_Abort(CAN_TypeDef * can_x, uint32_t transmitmailbox)
{
	CAN_CancelTransmit(can_x, transmitmailbox);
}

void CAN1_TransceiverInit(void)
{
 // GPIO_InitTypeDef  GPIO_InitStructure;

}

void CAN2_TransceiverInit(void)
{
 // GPIO_InitTypeDef  GPIO_InitStructure;

}

void CAN_FilterSet(void)
{
	CAN_FilterInitTypeDef  CAN_FilterInitStructure;

	CAN_FilterInitStructure.CAN_FilterNumber= 0;	  
	CAN_FilterInitStructure.CAN_FilterMode=CAN_FilterMode_IdMask; 
	CAN_FilterInitStructure.CAN_FilterScale=CAN_FilterScale_32bit;  

	CAN_FilterInitStructure.CAN_FilterIdHigh=0x0000; 
	CAN_FilterInitStructure.CAN_FilterIdLow=0x0000;

	CAN_FilterInitStructure.CAN_FilterMaskIdHigh=0x0000; 
	CAN_FilterInitStructure.CAN_FilterMaskIdLow=0x0000;

	CAN_FilterInitStructure.CAN_FilterFIFOAssignment=CAN_Filter_FIFO0;
	CAN_FilterInitStructure.CAN_FilterActivation=ENABLE; 
	CAN_FilterInit(&CAN_FilterInitStructure);	

	/*
	CAN_FilterInitStructure.CAN_FilterNumber= 18;	  
	CAN_FilterInitStructure.CAN_FilterMode=CAN_FilterMode_IdMask; 
	CAN_FilterInitStructure.CAN_FilterScale=CAN_FilterScale_32bit;  

	CAN_FilterInitStructure.CAN_FilterIdHigh=0x0000; 
	CAN_FilterInitStructure.CAN_FilterIdLow=0x0000;

	CAN_FilterInitStructure.CAN_FilterMaskIdHigh=0x0000; 
	CAN_FilterInitStructure.CAN_FilterMaskIdLow=0x0000;

	CAN_FilterInitStructure.CAN_FilterFIFOAssignment=CAN_Filter_FIFO1;
	CAN_FilterInitStructure.CAN_FilterActivation=ENABLE; 
	CAN_FilterInit(&CAN_FilterInitStructure);	
	*/
}


void Can_Hw_StartMode(uint8_t Controller)
{
	if(Controller == CAN_CONTROLLER1)
	{
		CAN_OperatingModeRequest(CAN1,CAN_OperatingMode_Normal);
	}
	if(Controller == CAN_CONTROLLER2)
	{
		CAN_OperatingModeRequest(CAN2,CAN_OperatingMode_Normal);
	}
}

void Can_Hw_StopMode(uint8_t Controller)
{
	if(Controller == CAN_CONTROLLER1)
	{
		CAN_OperatingModeRequest(CAN1,CAN_OperatingMode_Initialization);
	}
	if(Controller == CAN_CONTROLLER2)
	{
		CAN_OperatingModeRequest(CAN2,CAN_OperatingMode_Initialization);
	}
}

void Can_Hw_SleepMode(uint8_t Controller)
{
	if(Controller == CAN_CONTROLLER1)
	{
		CAN_OperatingModeRequest(CAN1,CAN_OperatingMode_Sleep);
	}
	if(Controller == CAN_CONTROLLER2)
	{
		CAN_OperatingModeRequest(CAN2,CAN_OperatingMode_Sleep);
	}
}

void Can_Hw_WakeUpMode(uint8_t Controller)
{
	if(Controller == CAN_CONTROLLER1)
	{
		CAN_OperatingModeRequest(CAN1,CAN_OperatingMode_Initialization);
	}
	if(Controller == CAN_CONTROLLER2)
	{
		CAN_OperatingModeRequest(CAN2,CAN_OperatingMode_Initialization);
	}
}
static uint8_t RevCount = 0;
uint8_t RevDone = 0;
void Can_Canif_Receive(uint8_t ControllerID,CanRxMsg* RxMessage)
{

	//CAN_Send_Msg(0, 0x01, RxMessage->Data, 8, 1);
	
    //memcpy(&Message[RevCount * 8],RxMessage->Data,8);
	RevCount ++;
	if(RevCount == 2)
	{
		RevCount = 0;
		RevDone = 1;
	}

	if(RxMessage->IDE== CAN_Id_Extended)
	{
	}
	else if(RxMessage->IDE == CAN_Id_Standard)
	{
	}

	//CanIf_RxIndication(&Mailbox, &PduInfo);
}




