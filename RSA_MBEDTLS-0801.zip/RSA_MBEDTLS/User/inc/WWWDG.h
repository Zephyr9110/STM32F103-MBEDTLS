#ifndef __WDG_H
#define __WDG_H

#include "stm32f10x.h"
#include "stm32f10x_wwdg.h"

void WWDG_Init(void);//��ʼ��WWDG

#endif
