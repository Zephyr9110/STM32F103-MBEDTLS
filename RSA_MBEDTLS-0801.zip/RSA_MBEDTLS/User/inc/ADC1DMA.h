#ifndef __ADC1DMA_H
#define __ADC1DMA_H

#include "stm32f10x.h"
#include "stm32f10x_adc.h"
#include "stm32f10x_rcc.h"

void ADC1DMA(void);
void ADC1DMA1(void);
void ADC1DMA2(void);
void TemperatureTest(void);



#endif

