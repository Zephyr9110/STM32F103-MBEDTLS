#ifndef _LEDKEYSERIALNUM_H
#define _LEDKEYSERIALNUM_H


void GPIOConfiguration(void);
void GPIOInterruptEnable(void);
void GPIOInterruptDisable(void);
void LedTest(void);
void IntTest(void);
void GetDeviceSerialID(void);

#endif
