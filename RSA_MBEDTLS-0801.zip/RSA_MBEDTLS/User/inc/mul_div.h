/**
  ******************************************************************************
  * File Name          : mul_div.c
  * Description        : This file provides code for div and mul
  *    
  ******************************************************************************
  * @attention
  ******************************************************************************
  */
	
#ifndef __mul_div_H
#define __mul_div_H
#ifdef __cplusplus
 extern "C" {
#endif
#include "stdint.h"

int CKS_MUL_DIV_Cal(void);

#ifdef __cplusplus
}
#endif
#endif /*__ usart_H */

