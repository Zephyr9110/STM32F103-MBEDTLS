#ifndef __TRIMTEST_H
#define __TRIMTEST_H		

#include "stm32f10x_rcc.h"


void TRIMTest(void);



#endif
