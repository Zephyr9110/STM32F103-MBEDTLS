#ifndef __CAN_H
#define __CAN_H	 
#include "sys.h"

#define CAN_RXTIEMOUT    500U /*500*10ms */
								 							 				    
uint8_t CAN1_Mode_Init(uint8_t tsjw,uint8_t tbs2,uint8_t tbs1,u16 brp,uint8_t mode);//CAN��ʼ��

uint8_t CAN_Send_Msg(uint8_t Controller, uint32_t id, uint8_t* data,  uint8_t dlc, uint16_t seq);

void CAN1_TransceiverInit(void);

void CAN2_TransceiverInit(void);

void CAN2_TransceiverInit(void);

void CAN_FilterSet(void);

void Can_Hw_SleepMode(uint8_t Controller);

void Can_Hw_StopMode(uint8_t Controller);

void Can_Hw_StartMode(uint8_t Controller);

void Can_Canif_Receive(uint8_t ControllerID,CanRxMsg* RxMessage);
u8 can1_init(u8 tsjw,u8 tbs1,u8 tbs2,u16 brp,u8 mode);
void can1_config(void);
#endif


#define CAN1_TX_INT_ENABLE	1		//0�ر�,����can�����ж�;1,ʹ��.	?,����can�����ж�
#define CAN1_ERR_INT_ENABLE 0


#define CAN_CONTROLLER1 0
#define CAN_CONTROLLER2 1

#define E_OK		0x00
#define E_NOT_OK	0x01

typedef enum
{
    CAN_OK = 0u,
    CAN_NOT_OK,
    CAN_BUSY
}Can_ReturnType;

extern uint8_t Message[];
extern uint8_t RevDone;










