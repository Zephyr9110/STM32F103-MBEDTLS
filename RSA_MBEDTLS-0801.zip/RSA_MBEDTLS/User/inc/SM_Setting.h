
#ifndef _SM_SETTING_H
#define _SM_SETTING_H

#include "SM_functions.h"
#include "SMDef.h"

StateTransit stateBindingTransit[]={
  //eventId                     nextState
	{EvtIdle,                     StateIdle},
  {EvtNull,                     StateInvalid}                      //EvtNull marks end of the table 
};

StateTransit stateIdleTransit[]={
  //eventId                     nextState
	{EvtBinding,                 StateBinding},
  {EvtNull,                     StateInvalid}                      //EvtNull marks end of the table 
};


StateSet SM_Table[]=
{
  {SBindingEntry,             SBindingExit,         SBindingAction,               stateBindingTransit},
  {SIdleEntry,                SIdleExit,            SIdleAction,                  stateIdleTransit},
};
#endif
