#ifndef __timer_H
#define __timer_H
#include "stm32f10x.h"
#include "grobal_def.h"


#define T1_H_PERIOD     72
#define T1_L_PERIOD     20

#define T0_H_PERIOD     20
#define T0_L_PERIOD     72

#define LED_NUM  12 

void PWM_DMA_Init(void);
void SetTim3Period(uint8_t period);
void LedColorReset(void);
void LedSetColor(uint8_t LedIndex,uint8_t color,uint8_t britness);
void PWM_DMA_Init(void);
void NVIC_TIM2Disbale(void);
void NVIC_TIM3Disbale(void);
void NVIC_TIM4Disbale(void);
void NVIC_TIM3Enbale(void);
void Tim3Int_Enable(void);
void TIM2_Init(void);
void TIM3_Init(void);
void TIM4_Init(void);
extern uint8_t Time3SetFlag;
#endif

