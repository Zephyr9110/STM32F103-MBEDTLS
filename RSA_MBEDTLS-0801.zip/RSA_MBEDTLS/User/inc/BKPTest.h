#ifndef __BKPTEST_H
#define __BKPTEST_H	
#include "stm32f10x.h"
#include "stm32f10x_bkp.h"
#include "stm32f10x_pwr.h"
void BKPTest(void);
#endif
