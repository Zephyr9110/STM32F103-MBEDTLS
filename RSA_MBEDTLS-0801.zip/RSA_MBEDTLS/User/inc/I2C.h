#ifndef __I2C_FRAM_H 
#define __I2C_FRAM_H 

#include "stm32f10x.h"
#include "grobal_def.h"
#include "UserDrv.h"
#include "stdbool.h"


/* Includes ------------------------------------------------------------------*/ 
#define I2C_Speed              100000 	  //400000
#define I2C_PageSize           8

#define SCL_H         GPIO_SetBits(GPIOB,GPIO_Pin_6)
#define SCL_L         GPIO_ResetBits(GPIOB,GPIO_Pin_6)

#define SDA_H         GPIO_SetBits(GPIOB,GPIO_Pin_7)
#define SDA_L         GPIO_ResetBits(GPIOB,GPIO_Pin_7)

#define SCL_read      GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_6)
#define SDA_read      GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_7)




void I2C_Configuration(void);
void I2C_delay(void) ;
bool I2C_Start(void) ;
void I2C_Stop(void) ;
void I2C_Ack(void);
void I2C_NoAck(void) ;
bool I2C_WaitAck(void);
void I2C_SendByte(u8 SendByte); //���ݴӸ�λ����λ// 
u8 I2C_ReceiveByte(void);  //���ݴӸ�λ����λ//


/*
bool I2C_FRAM_BufferWrite(u8 I2C1_SLAVE_ADDRESS7, u8* pBuffer, u16 WriteAddr, u16 NumByteToWrite);
bool I2C_FRAM_BufferRead(u8 I2C1_SLAVE_ADDRESS7, u8* pBuffer, u16 WriteAddr, u16 NumByteToRead);
*/
#endif /* __I2C_FRAM_H */ 
