#ifndef __PCF8563_H
#define __PCF8563_H

#include "I2C.h"

bool PCF8563_I2C_FRAM_BufferWrite(u8 I2C1_SLAVE_ADDRESS7,u8* pBuffer, u8 WriteAddr, u8 NumByteToWrite);
bool PCF8563_I2C_FRAM_BufferRead(u8 I2C1_SLAVE_ADDRESS7, u8* pBuffer, u16 WriteAddr, u16 NumByteToRead) ;

void I2C_PCF8563(void);
void I2C_PCF8563CLKOUT(void);



#endif
