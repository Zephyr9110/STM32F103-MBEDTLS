#ifndef __GrobalDef_H
#define __GrobalDef_H

/* Exported macro ------------------------------------------------------------*/
#define FALSE 0
#define TRUE  1


#endif
