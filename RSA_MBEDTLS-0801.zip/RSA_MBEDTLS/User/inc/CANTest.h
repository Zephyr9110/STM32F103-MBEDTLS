#ifndef __CANTEST_H
#define __CANTEST_H



void CANTest(void);

#endif
