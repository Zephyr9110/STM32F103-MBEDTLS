#ifndef __PRINTF_H
#define __PRINTF_H

/* Includes ------------------------------------------------------------------*/
#include "stm32f10x.h"
#include <stdio.h>
#include "UserDrv.h"
#include "stm32100e_eval.h"

#ifdef __cplusplus
 extern "C" {
#endif


void Printf_Init(void);

    
#ifdef __cplusplus
}
#endif
#endif 
/******************* (C) COPYRIGHT 2013 www.armjishu.com *****END OF FILE****/

