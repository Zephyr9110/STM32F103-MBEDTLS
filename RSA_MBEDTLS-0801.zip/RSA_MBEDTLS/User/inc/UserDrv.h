#ifndef _USER_DRV_H
#define _USER_DRV_H
#include "stm32f10x.h"

#define COMn                             2

/**
 * @brief Definition for COM port1, connected to USART1
 */ 
#define EVAL_COM1                        USART1
#define EVAL_COM1_CLK                    RCC_APB2Periph_USART1
#define EVAL_COM1_TX_PIN                 GPIO_Pin_9
#define EVAL_COM1_TX_GPIO_PORT           GPIOA
#define EVAL_COM1_TX_GPIO_CLK            RCC_APB2Periph_GPIOA
#define EVAL_COM1_RX_PIN                 GPIO_Pin_10
#define EVAL_COM1_RX_GPIO_PORT           GPIOA
#define EVAL_COM1_RX_GPIO_CLK            RCC_APB2Periph_GPIOA
#define EVAL_COM1_IRQn                   USART1_IRQn

/**
 * @brief Definition for COM port2, connected to USART2
 */ 
#define EVAL_COM2                        USART2
#define EVAL_COM2_CLK                    RCC_APB1Periph_USART2
#define EVAL_COM2_TX_PIN                 GPIO_Pin_2
#define EVAL_COM2_TX_GPIO_PORT           GPIOA
#define EVAL_COM2_TX_GPIO_CLK            RCC_APB2Periph_GPIOA
#define EVAL_COM2_RX_PIN                 GPIO_Pin_3
#define EVAL_COM2_RX_GPIO_PORT           GPIOA
#define EVAL_COM2_RX_GPIO_CLK            RCC_APB2Periph_GPIOA
#define EVAL_COM2_IRQn                   USART2_IRQn



/* spi1.c -----------------------------------------------------------*/
#define RCC_SPI1_CLK                RCC_APB2Periph_SPI1
#define SPI1_GPIO_PORT     GPIOA
#define RCC_SPI1      RCC_AHB1Periph_GPIOA
#define SPI1_NSS      GPIO_Pin_4     /*GPIOA*/
#define SPI1_SCK      GPIO_Pin_5
#define SPI1_MISO      GPIO_Pin_6
#define SPI1_MOSI      GPIO_Pin_7
					  
void SPI1_Init(uint8_t ch);			 //��ʼ��SPI��
u8 SPI1_ReadWriteByte(u8 TxData);//SPI���߶�дһ���ֽ�
void SPI_test(void);

/* spi2.c -----------------------------------------------------------*/
#define RCC_SPI2_CLK                RCC_APB2Periph_SPI1
#define SPI2_GPIO_PORT     GPIOB
#define RCC_SPI2      RCC_AHB1Periph_GPIOB
#define SPI2_NSS      GPIO_Pin_12     /*GPIOA*/
#define SPI2_SCK      GPIO_Pin_13
#define SPI2_MISO      GPIO_Pin_14
#define SPI2_MOSI      GPIO_Pin_15
					  
void SPI2_Init(void);			 //��ʼ��SPI��
u8 SPI2_ReadWriteByte(u8 TxData);//SPI���߶�дһ���ֽ�
void SPI_test(void);


/* I2C.c -----------------------------------------------------------*/
#define RCC_I2C                RCC_APB2Periph_GPIOB
#define I2C_GPIO_PORT     GPIOB
#define RCC_I2C      RCC_APB2Periph_GPIOB
#define I2C_SDA      GPIO_Pin_6     
#define I2C_SCL      GPIO_Pin_7


void ModuleInit(void);
#endif
