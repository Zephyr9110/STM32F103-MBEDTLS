#ifndef __timer1234_H
#define __timer1234_H
#include "stm32f10x.h"
#include "grobal_def.h"

void SetTimerFlg(void);
void ResetTimerFlg(void);
u8 GetTimerFlag(void);
void TIM2_Init(void);
void TIM3_Init(void);
void TIM4_Init(void);
void NVIC_TIM2Disbale(void);
void NVIC_TIM3Disbale(void);
void NVIC_TIM4Disbale(void);
void NVIC_TIM3Enbale(void);
void GPIO_PWM_TIMER1_Configuration(void);
void GPIO_PWM_TIMER1_Test(void);
void GPIO_PWM_DEAD_TIMER1_Configuration(void);
void GPIO_PWM_DEAD_TIMER1_Test(void);



#endif
