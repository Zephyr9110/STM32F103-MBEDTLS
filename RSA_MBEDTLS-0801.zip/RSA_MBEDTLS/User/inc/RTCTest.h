#ifndef __RTCTEST_H
#define __RTCTEST_H
void RTCTest(void);
void HSI_TEST();
#endif 
