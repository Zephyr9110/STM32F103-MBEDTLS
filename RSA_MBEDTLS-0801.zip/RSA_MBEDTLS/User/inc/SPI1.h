#ifndef __SPI1_H
#define __SPI1_H
#include "stm32f10x.h"
#include "UserDrv.h"
#include "main.h"
#include "Flash.h" 

						  	    													  
void SPI1_Init(uint8_t ch);			 //��ʼ��SPI��
u8 SPI1_ReadWriteByte(u8 TxData);//SPI���߶�дһ���ֽ�
void SpiFLashTest(void);		
void SpiFLashTest1(void);
#endif

