#ifndef _SME_DEF_H
#define _SME_DEF_H

#include "stm32f10x.h"

/**/

///////////////////////////////////////////////////////////////////
//StateIdle:����״̬���ȴ��п�CPU������
///////////////////////////////////////////////////////////////////
typedef enum 
{                 
  StateBinding,  					/*���а󶨡�������°󶨲���ʱ��״̬*/
	StateIdle,              /*����״̬*/
  StateCount,
  StateInvalid 
}StateId;

typedef enum 
{
  EvtBinding,
	EvtIdle,
	EvtCount,
  EvtNull                      //for marking the end of a transition tabele
}EventId;

typedef enum 
{
	GERROR_OK,            				//�޴���״̬	
  GERROR_SHC_TIMEOUT,            //�ȴ���ȫоƬ��ʱ����
  GERRORCount ,
  GERRORNull                      	//for marking the end of a transition tabele
}GlobalErrorCode;//ȫ�ִ������


typedef struct
{
  StateId globalState; 
	u8 localState;
	GlobalErrorCode globalError;//��¼ȫ�ִ������
	u8 errorLocalState;					//������ʱ�����ľֲ�״̬��״̬
	//
}Context;


typedef struct
{
  EventId     eventId;
  u8          param;  
	Context     context;
}EventInfo;

typedef void (*HStateEntry)(EventId id, u8 eventParam, Context* context);                              //function pointer to point a state entry function.
typedef void (*HStateExit)();                               //function pointer to point a state exit function.
typedef u8 (*HStateAction)(EventInfo* pEvtInfo);    //function pointer

typedef struct
{
  EventId               eventId;
  StateId               nextState;
}StateTransit;
  

typedef struct
{
  HStateEntry                   hStateEntry; 
  HStateExit                    hStateExit; 
  HStateAction                  hStateAction;
  StateTransit*         				pStateTransit; 
}StateSet;
  
 


#endif
