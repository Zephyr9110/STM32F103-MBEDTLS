#ifndef __IWDG_H
#define __IWDG_H



void IWDGtest(void);
//void IWDGtest_LKJ(void);

#endif
