#ifndef __DMATEST_H
#define __DMATEST_H


void DmaMem2Uart(void);
void DmaMem2Mem(void);

#endif
