/******************** (C) COPYRIGHT 2013  ********************
* File Name          :  main.c
* Author             :  Wanly Hang
* Version            :  V1.0
* Date               : 2015-6-17
* Description        :  main
*******************************************************************************/



#include "main.h"
#include "mul_div.h"
#include "timer3.h"
#include  "can.h"
#include "SPI1.h"
#include "stdlib.h"
#include "stm32f10x_it.h"
#include "stdlib.h"
#include "math.h"

#include "mbedtls/entropy_poll.h"
#ifdef WEIDU_TEST
__IO uint32_t Result = 0; /* for return of the interrupt handling */
void GPIO_Configuration(void);
void NVIC_Configuration(void);
int CAN_Polling(void);
int CAN_Interrupt(void);
#endif


				
u8 HseReady_Flag = 0;
signed int MulDiv_CalFlg = 0;
static uint32_t TimingDelay;

void delay_1000us(uint32_t delay_conter)
{
	SysTick_Config((uint32_t)9000);
	SysTick_CLKSourceConfig(SysTick_CLKSource_HCLK_Div8);

	TimingDelay = delay_conter;
	while(TimingDelay != 0);
}
void delay_8us(uint32_t delay_conter)
{
	SysTick_Config((uint32_t)72);
	SysTick_CLKSourceConfig(SysTick_CLKSource_HCLK_Div8);

	TimingDelay = delay_conter;
	while(TimingDelay != 0);
}
void TimingDelay_Decrement(void)
{
  if (TimingDelay != 0x00)
  { 
    TimingDelay--;
  }
}
uint32_t ModData = 0;
void TestOut_GpioInit()
{
	GPIO_InitTypeDef GPIO_InitStructure;

	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);   
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_4;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz; 
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
    GPIO_Init(GPIOA,&GPIO_InitStructure);
	//GPIO_SetBits(GPIOA,GPIO_Pin_4);
	GPIO_ResetBits(GPIOA,GPIO_Pin_4);
	//printf("IO HIGH-LOW\r\n");
	
}
extern int mbedtls_rsa_test(void);
extern int mbedtls_rsa_sign_test(void);

int main(void)
{	
	SystemInit();
	Printf_Init();
	TIM4_Init();
	srand(Timer4_IntUs);
	TestOut_GpioInit();
	
	while(1)
	{
		mbedtls_rsa_sign_test();
	}
}